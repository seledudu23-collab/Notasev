# Nota-Se Mobile — projeto Android
Este pacote contém o código-fonte do aplicativo Nota-Se. **Não contém APK compilado**.

## Compilar no Android Studio
1. Instale Android Studio (com Android SDK) e JDK 17.
2. Abra esta pasta como projeto.
3. Aguarde a sincronização e escolha Build > Build APK(s).
4. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Gerar APK pelo GitHub Actions
O workflow `.github/workflows/android.yml` compila quando enviado para branch `main` ou manualmente pelo menu Actions > Build Nota-Se APK. O arquivo APK aparece como Artifact `Nota-Se-apk`.
